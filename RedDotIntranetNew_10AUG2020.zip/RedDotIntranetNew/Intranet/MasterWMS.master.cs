﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Intranet_MasterWMS : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    //protected void lbhome_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("~/Intranet/home.aspx");
    //}
    //protected void lbprealert_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("~/Intranet/WMS/List_Prealert.aspx");
    //}
    //protected void lbBOE_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("~/Intranet/WMS/BOelist.aspx");
    //}
    //protected void LBDO_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("~/Intranet/WMS/ListDo.aspx");
    //}
    //protected void lbRDO_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("~/Intranet/WMS/ListReserveOrder.aspx");
    //}
    //protected void lbStock_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("~/Intranet/WMS/Stockbywarehouse.aspx");
    //}

    //protected void lbStockHistory_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("~/Intranet/WMS/StockMoveHistory.aspx");
    //}
    //protected void lbStockSheet_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("~/Intranet/WMS/StockSheet.aspx");
    //}
    //protected void lbadmin_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("~/Intranet/WMS/customer.aspx");
    //}
}
