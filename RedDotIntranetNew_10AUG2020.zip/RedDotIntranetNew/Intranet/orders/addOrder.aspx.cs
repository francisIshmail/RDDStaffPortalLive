﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Intranet_orders_addOrder : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //string orderId, type;
        //orderId=Request.QueryString["orderId"].ToString();
        //type=Request.QueryString["type"].ToString();

        //if (!IsPostBack)
        //{
        //    lblOrderId.Text = orderId;
        //    lblType.Text = type;
        //}
    }
}