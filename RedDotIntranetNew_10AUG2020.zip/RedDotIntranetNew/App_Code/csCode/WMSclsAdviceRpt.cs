﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

  public class AdviceRpt
    {
        public string marksNumber { get; set; }

        public string type { get; set; }
        public string Qty { get; set; }
        public string WeightKgs { get; set; }
        public string VolumeCbm { get; set; }
        public string Description { get; set; }
        public string ExitPoint { get; set; }
        public string Destination { get; set; }
        public string Amount { get; set; }
        public string import { get; set; }

        public string temporary { get; set; }
        public string export { get; set; }
        public string reExport { get; set; }

        public string FZTranfer { get; set; }
        public string cdrCash { get; set; }
        public string cdtBank { get; set; }


        public string deposit { get; set; }
        public string creditAC { get; set; }
        public string bankG { get; set; }
        public string stanG { get; set; }

        public string ftt { get; set; }
        public string alcohol { get; set; }
        public string other { get; set; }
    }

 
