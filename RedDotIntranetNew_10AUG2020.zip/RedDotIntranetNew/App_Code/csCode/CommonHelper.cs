﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.IO;
using System.Net;


    public struct RunningCache
    {
        public static string AdviceRpt = "AdviceRpt";
        public static string UserID = "UserID";
        public static string boeID = "boeID";
        public static string reserveCustomer = "reserveCustomer";
        public static string reserveorder = "reserveorder";
        public static string reserveNote = "reserveNote";
        public static string Username = "Username";
        public static string mailshotid = "mailshotid";
        public static string Country = "Country";
        public static string CountryID = "CountryID";
       
    }

   