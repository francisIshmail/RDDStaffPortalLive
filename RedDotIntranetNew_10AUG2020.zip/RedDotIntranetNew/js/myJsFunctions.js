﻿function getConfirmation() {
    return confirm('Are you sure you want to perfom this action ?');
}
function getConfirmationNextLevel() {
    return confirm('Are you sure you want continue updating this plan to next level ?');
}