﻿
function getConfirmation() {
    return confirm('Are you sure you want to perfom this action ?');
}